<?php
  
  /**
  * Configuration pour database connection
  *
  */
  
  $host       = "localhost";
  $username = "votre login mysql";
  $password = "votre mdp mysql";
  $dbname     = "epi";
  
  $root       = __DIR__.'/';
  
  $dossier_images     = $root."images/";
  $dossier_enregistrements = $root."enregistrements/";
  $dossier_factures = $root."factures/";
?>