        <hr>
        <div class="container">
            <div class="row">
                <table>
                    <tr>
                        <td align="left"><img src="images/EPIClub.png" alt="Logo EPIClub" width="100" class="img-fluid"></td>
                        <td align="center"><h1>Gestionnaire EPI</h1></td>
                        <td align="right"><img src="images/logo.png" width="150" alt="Logo Périgord Escalade" class="img-fluid"></td>
                    </tr>
                </table>
            </div>
        </div>
        <hr>