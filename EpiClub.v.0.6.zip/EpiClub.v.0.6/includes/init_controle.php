<?php
	
	function init_controle() {
		$donnees = array(
			'id' => 0,
			'utilisateur_id' => 1,
			'remarques' => '',
		);
		return $donnees;
	}
	
?>