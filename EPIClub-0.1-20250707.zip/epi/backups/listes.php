<?php
	
	# #############################
	# initialisation des listes 
	# #############################
	
	# Récupération des lieux
	
	$statement = $connection->query("SELECT * FROM lieu ORDER BY id");
	$nLieux = $statement->num_rows;
	$lieux = $statement->fetch_all(MYSQLI_ASSOC);
	
	# Récupération des categories
	$statement = $connection->query("SELECT * FROM categorie ORDER BY id");
	$nCategorie = $statement->num_rows;
	$categories = $statement->fetch_all(MYSQLI_ASSOC);
	
	#  Récupération des lieux
	$statement = $connection->query("SELECT * FROM fabricant ORDER BY id");
	$nFab = $statement->num_rows;
	$fabricants = $statement->fetch_all(MYSQLI_ASSOC);
	
	
	# Récupération des lieux
	$statement = $connection->query("SELECT * FROM facture ORDER BY id");
	$nFacture = $statement->num_rows;
	$factures = $statement->fetch_all(MYSQLI_ASSOC);
	
	# #############################
	# Création des listes 
	# #############################
	
	$listeLieux = "";
	
	for ($i = 1; $i < $nLieux; $i++)
		{
			$listeLieux .="<option value= '".$lieux[$i]["id"]."'>".escape($lieux[$i]["libelle"])." </option>";
			
		};
	
	$listeCategories = "";
	
	for ($i = 0; $i < $nCategorie; $i++)
		{
			$listeCategories = $listeCategories."<option value= '".$categories[$i]["id"]."'>".escape($categories[$i]["libelle"])." </option>";
		};
	
	$listeFabricants = "";
	
	for ($i = 0; $i < $nFab; $i++)
		{
			$listeFabricants = $listeFabricants."<option value= '".$fabricants[$i]["id"]."'>".escape($fabricants[$i]["libelle"])." </option>";
		};
	
	$listeFactures = "";
	
	for ($i = 0; $i < $nFacture; $i++)
		{
			$listeFactures .="<option value= '".$factures[$i]["id"]."'>".escape($factures[$i]["vendeur"])."-".escape($factures[$i]["date_facture"])." </option>";
			
		};
	
?>