<?php

if ($_POST['action']== 'Mise à jour') {
	$miseAJour = true;
	$action = "maj";
	$id = $_POST['id'];
	$nbInitial = intval($_POST['nb_elements_initial']);
	$action = "maj";
	$bouton = "Enregistrer la fiche";
}
else {
	$miseAJour = false;
	$id = 0;
	$nbInitial = 1;
	$bouton = "Mettre à jour la fiche";
	$action = "creation";    
};
	

if ($_POST['action'] == "maj") {
	echo "mise à jour";
}
else if {$_POST['action'] == "creation") {
	echo "creation";
}
	else {
		echo "erreur";
	};
?>

