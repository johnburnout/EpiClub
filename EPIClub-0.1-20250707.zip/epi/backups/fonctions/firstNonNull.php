<?php
	function firstNonNull(...$values) {
		foreach ($values as $value) {
			if ($value !== null) {
				return $value;
			}
		}
		return null;
	}
?>