<?php
session_start();

  require "header.php";
  require "config.php";  
  require "common.php";

  # #############################
  # verification connexion
  # #############################
  
  if (count($_SESSION) > 0)	
    {
      $connect = "Connecté comme ".$_SESSION['pseudo']." : ";
    }
  else
    {
      $connect = "Déconnecté";
    }

  
  mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
  
  # #############################
  # Initialisation variables 
  # #############################
  
  if (isset($_POST['id'])) {$id = $_POST['id'];}
  else {$id = 0; };
  
  # #############################
  # Mise à jour des données de la fiche 
  # #############################
  
  #
  #echo "<br>\$POST :"; var_dump($_POST); echo "<br>"; #<-------------------------
  #
  if ($_POST['action'] = "maj") {
    
    try {
      $connection = new mysqli($host, $username, $password, $dbname);
      
#
#      echo "\$PHOTO avant update : ".$_POST["photo"]."<br>"; #<-------------------------
#
      
      $lieu_id = strval(intval($_POST['lieu_id'])-1);
      
      #
      #     echo "\$lieu_i avant update : ".$lieu_id."<br>"; #<-------------------------
      #
      
      
      $sql = "UPDATE matos SET 
        photo = '".$_POST["photo"]."',
        nb_elements = '".$_POST["nb_elements"]."',
        remarques = '".escape($_POST["remarques"])."',
        lieu_id = ".$lieu_id."
        WHERE id = ".$id." ;";

      $statement = $connection->query($sql);

      $connection->close();

    } catch(Exception $error) {
      echo $sql . "<br>" . $error->getMessage();
    };
  }  

  # #############################
  # Récupération des données à la BDD 
  # #############################
  
  $result = NULL;
  #
  #     echo "\$id avant update : ".$id."<br>"; #<-------------------------
  #
  try {
    $connection = new mysqli($host, $username, $password, $dbname);

    $sql = "SELECT
      id, ref, libelle, categorie, fabriquant, photo, lieu, lieu_id, nb_elements, date_max, date_verification, remarques
    FROM fiche
    WHERE id = ".$id." ;";

    $statement = $connection->query($sql);

    $result = $statement->fetch_all(MYSQLI_ASSOC);

    #
    # echo "<br>\$RESULT :"; var_dump($result)."<br>"; #<----------------------VERIF
    #  
  
#   Récupération des lieux
    
    $statement = $connection->query("SELECT * FROM lieu ORDER BY id");
    $nLieux = $statement->num_rows;
    $lieux = $statement->fetch_all(MYSQLI_ASSOC);
    $connection->close();

  } catch(Exception $error) {
    echo $sql . "<br>" . $error->getMessage();
  }
  #
  # echo "<br>\$lieux :"; var_dump($lieux)."<br>"; #<----------------------VERIF
  #
  
  # #############################
  # Création des listes 
  # #############################
  
  #
  #echo "<br>\$result[0]['lieu_id'] :"; print_r($result[0]['lieu_id'])."<br>"; #<----------------------VERIF
  #  
  
  #$listeLieux = $lieux;
  $lieux[$result[0]['lieu_id']]['id'] .=" selected";
  
  #$listeLieux[$result[0]['lieu_id']] .= " selected";
  
  #
  #echo "<br>\$Lieux :"; print_r($lieux)."<br>"; #<----------------------VERIF
  #echo "<br>\$lieux :"; escape(print_r($lieux)); echo "<br>"; #<----------------------VERIF
  #  
  
  $listeLieux = "";
  
  for ($i = 0; $i < $nLieux; $i++)
    {
      $listeLieux .="<option value= ".$lieux[$i]["id"].">".$lieux[$i]["libelle"]." </option>";
      
    };
  
  #
  #  echo "<br>\$listeLieux : ".escape($listeLieux)."<br>"; # <------------------------- VERIF
  #  
  
  # #############################
  # Envoi de fichier
  # #############################
  
  #
  #  echo "<br>\FILES :"; var_dump($_FILES)."<br>"; #<----------------------VERIF
  #
  if (count($_FILES)>0){

    
      $nomOrigine = $_FILES['monfichier']['name'];
      $elementsChemin = pathinfo($nomOrigine);
      
#
#        echo "<br>\$elementsChemin :"; var_dump($elementsChemin)."<br>";  #<----------------------VERIF
#
      if ($elementsChemin["filename"]) {$extensionFichier = $elementsChemin['extension'];};
      $extensionsAutorisees = array("jpeg", "jpg", "gif","png");

#    
#    echo "<br>\$extensionFichier :"; var_dump($extensionFichier)."<br>"; #<----------------------VERIF
#            
            
      if(isset($extensionFichier))
        {      
      if (!(in_array($extensionFichier, $extensionsAutorisees)))
      {
        echo "Le fichier n'a pas l'extension attendue";
      }
      else
      {    
        // Copie dans le repertoire du script avec un nom comprenant la date
        $repertoireDestination = dirname(__FILE__)."/images/";
        $nomDestination = $result[0]["ref"].date("Ymd").".".$extensionFichier;
        
        if (move_uploaded_file($_FILES["monfichier"]["tmp_name"], 
          $repertoireDestination.$nomDestination))
          {
            echo "<hr>Le fichier temporaire ".$_FILES["monfichier"]["tmp_name"].
            " a été déplacé vers ".$repertoireDestination.$nomDestination."<hr>";
          }
        else
          {
            echo "<hr>ATTENTION : Le fichier n'a pas été uploadé (trop gros ?) ou ".
            "Le déplacement du fichier temporaire a échoué".
            " vérifiez l'existence du répertoire ".$repertoireDestination."<hr>";
          }
      };
        };
    
    
        if (isset($nomDestination))
          {
            try {
            $connection = new mysqli($host, $username, $password, $dbname);
            
            $sql = "UPDATE matos SET 
            photo = '".$nomDestination."' WHERE id = ".$result[0]["id"]." ;";
            
            $statement = $connection->query($sql);
            
            $connection->close();
              
            } catch(Exception $error) {
              echo $sql . "<br>" . $error->getMessage();
          }
          };
    };
    
  #
  #echo "<br>\$DESTINATION :"; var_dump($destination)."<br>";  #<----------------------VERIF
  #
  
if(isset($nomDestination))  
{
  if ($nomDestination<>'')
    {
      $photo = $nomDestination;
    };

  }
  else {
    $photo = $result[0]["photo"];    
  };

  #
  #echo "<br>\$PHOTO :"; var_dump($photo)."<br>";  #<----------------------VERIF
  #
  
  
  # #############################
  # Code HTML 
  # #############################
?>
<body><p align="right">
  <?php 
    if (count($_SESSION) > 0)
  { ?>
  <form action="index.php" method="post"><?php echo $connect." "; ?><input type='submit' name="deconnexion" value="Déconnexion"></form><?php  
    }
    else 
  { ?>
  <a href=login.php>Connection</a><?php
    }
  ?></p>
  <hr>
  <table>
    <tr>
      <td> <h1>Gestionnaire EPI</h1></td><td rowspan=2><img src="images/logo.png" width="200"></td>
    </tr>
    <tr><td><h2>Périgord Escalade</h2></td></tr>
  </table>
  
<?php  if ($result <> NULL ) { ?>

<hr>
  <!-- Test si connecté debut -->
  <?php if (count($_SESSION) > 0)
    { 
  ?>
  <!---->
<h3>Fiche EPI</h3>

<!--Affichage de la fiche-->
   
<form enctype="multipart/form-data" action="#" method='post'>
    <table>
    <tbody>
        <tr>
          <th>Ref</th>
          <td><?php echo $result[0]["ref"]; ?></td><td>Photo</td><td><textarea rows=1 name="photo"><?php echo $photo;?></textarea></td>
        </tr>
        <tr>
          <th>Libelle</th>
          <td><?php echo $result[0]["libelle"]; ?></td><td rowspan = 7 colspan=2><img src = "<?php echo "images/".$photo;?>" width='400'></td>
        </tr>
        <tr>
          <th>Categorie</th>
          <td><?php echo $result[0]["categorie"]; ?></td>
        </tr>
        <tr>
          <th>Fabricant</th>
          <td><?php echo $result[0]["fabriquant"]; ?></td>
        </tr>
        <tr>
          <th>Lieu</th>
          <td>
            <select name='lieu_id'>
              <?php echo $listeLieux ?>
            </select>
          </td>
        </tr> 
        <tr>
          <th>Nb elements</th>
          <td>
            <input type=number name="nb_elements" min=0 max=<?php echo $result[0]["nb_elements"];?> value=<?php echo $result[0]["nb_elements"];?>>
            </td>
        </tr>
        <tr>
          <th>Date max</th>
          <td><?php echo $result[0]["date_max"]; ?> </td>
        </tr>
        <tr>
          <th>Date verif</th>
          <td><?php echo $result[0]["date_verification"]; ?> </td>
        </tr>
        <tr>
          <th colspan =4 >remarques</th>
        </tr>
        <tr>
          <td colspan = 4><textarea name="remarques" cols = 100 rows=5 ><?php echo $result[0]["remarques"]; ?></textarea> </td>
        </tr>
        <tr>
        <td><input type="hidden" name="MAX_FILE_SIZE" value="2000000" />  Envoyer une image : </td>
        <td><input type="file" name="monfichier" /></td>
      </tr>
        </tbody>
    </table>
  <input type='hidden' name='id' value =<?php echo $id ?> >
  <p></p>
  <input type="submit" name="maj" value="Mettre à jour">
</form>

  <!-- envoi de la photo -->


<hr>
<p>
  <a href='liste_selection.php'><strong>Retour à la liste</strong></a> - Saisir de nouveaux EPI
</p>
<p>
  <a href="index.php"><strong>Retour à l'accueil</strong></a> - Revenir à l'accueil
</p>

<?php } else { ?>
<p>Pas de fiche trouvée.</p>
 <?php
} ?>
<p></p>


  <!-- Test si connecté fin -->
  <?php 
    }
    else { ?>
  <p>Tu n'es pas connecté</p>
  <?php 
  }?>

  <!---->
  
<?php require "footer.php"; ?>