<?php
session_start();
# #############################
# Récupère les données communes
# #############################

include $root."includes/header.php";
require "config.php";  
include $root."includes/common.php";;

  
  #
#echo "<br>\$_POST : "; print_r($_POST); echo "<br>"; # <------------------------- VERIF
  #


  # #############################
  # verification connexion
  # #############################
  
  #
  #  echo "<br>\$_SESSION :"; var_dump($_SESSION)."<br>"; # <------------------------- VERIF
  #
  if (count($_SESSION) > 0)	
    {
      $connect = "Connecté comme ".$_SESSION['pseudo']." : ";
    }
  else
    {
      $connect = "Déconnecté";
    }




  
# #############################
# Création de la connection à la base
# #############################

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$connection = new mysqli($host, $username, $password, $dbname);

# #############################
# initialisation des listes 
# #############################

# Récupération des lieux

$statement = $connection->query("SELECT * FROM lieu ORDER BY id");
$nLieux = $statement->num_rows;
$lieux = $statement->fetch_all(MYSQLI_ASSOC);

# Récupération des categories
$statement = $connection->query("SELECT * FROM categorie ORDER BY id");
$nCategorie = $statement->num_rows;
$categories = $statement->fetch_all(MYSQLI_ASSOC);

#
#echo "<br>\$categories : "; var_dump($categories); echo "<br>"; # <------------------------- VERIF
#


#  Récupération des lieux
$statement = $connection->query("SELECT * FROM fabricant ORDER BY id");
$nFab = $statement->num_rows;
$fabricants = $statement->fetch_all(MYSQLI_ASSOC);


# Récupération des lieux
$statement = $connection->query("SELECT * FROM facture ORDER BY id");
$nFacture = $statement->num_rows;
$factures = $statement->fetch_all(MYSQLI_ASSOC);

  # #############################
  # Création des listes 
  # #############################
  
  $lieux[$_POST['lieu_id']-1]['id'] .=" selected";
  
  $listeLieux = "";
  
  for ($i = 1; $i < $nLieux; $i++)
    {
      $listeLieux .="<option value= ".$lieux[$i]["id"].">".$lieux[$i]["libelle"]." </option>";
      
    };
  
  #
  #  echo "<br>\$listeLieux : ".escape($listeLieux)."<br>"; # <------------------------- VERIF
  #  
  
  $listeCategories = "";
  
  #
  #echo "<br>\$_POST : "; print_r($_POST['categorie_id']); echo "<br>"; # <------------------------- VERIF
  #
  #echo "<br>\$categories : "; print_r($categories[$_POST['categorie_id']-1]['id']); echo "<br>"; # <------------------------- VERIF
  #
  
  $categories[$_POST['categorie_id']-1]['id'] .=" selected";
  
  #
  #  echo "<br>\$categories : "; print_r($categories); echo "<br>"; # <------------------------- VERIF
  #  
  
  for ($i = 0; $i < $nCategorie; $i++)
    {
      $listeCategories = $listeCategories."<option value= ".$categories[$i]["id"].">".$categories[$i]["libelle"]." </option>";
    };
  
  #
  # echo "<br>\$listeCategories : ".escape($listeCategories)."<br>"; # <------------------------- VERIF
  #  
  
  
  $listeFabricants = "";
  
  $fabricants[$_POST['fabricant_id']-1]['id'] .=" selected";
  
  for ($i = 0; $i < $nFab; $i++)
    {
      $listeFabricants = $listeFabricants."<option value= ".$fabricants[$i]["id"].">".$fabricants[$i]["libelle"]." </option>";
    };
  
  $listeFactures = "";
  
  $factures[$_POST['facture_id']-1]['id'] .=" selected";
  
  for ($i = 0; $i < $nFacture; $i++)
    {
      $listeFactures = $listeFactures."<option value= ".$factures[$i]["id"].">".$factures[$i]["vendeur"]." </option>";
      
    };
  

# #############################
# Initialisation variables 
# #############################
  
  #
  #  echo "<br>\$_POST :"; var_dump($_POST)."<br>"; # <------------------------- VERIF
  #

if (isset($_POST['id'])) {$id = $_POST['id'];}
else {$id = 0; };

if(isset($_POST['nb_elements_initial']))
  {
    $nbInitial = max(intval($_POST['nb_elements_initial']),1);
  }
else {
  $nbInitial = 1;
};

# #############################
# Envoi des données à la BDD 
# #############################

if (isset($_POST['envoyer'])) {
  try {
  $sql = "UPDATE matos SET
    reference = '".$_POST['reference']."',
    libelle = '".escape($_POST['libelle'])."',
    categorie_id = '".$_POST['categorie_id']."',
    fabricant_id = '".$_POST['fabricant_id']."',
    photo = '".$_POST['photo']."',
    lieu_id = '".$_POST['lieu_id']."',
    date_debut = '".$_POST['date_debut']."',
    nb_elements_initial = '".$nbInitial."',
    nb_elements = '".$nbInitial."',
    facture_id = '".$_POST['facture_id']."',
    remarques = '".escape($_POST['remarques'])."'
  WHERE
    id = ".$id.";
    ";
  
  $statement = $connection->query($sql);
  }
  catch(Exception $error)
  {
    echo $sql . "<br>" . $error->getMessage();
  }
}  
  
$result = NULL;

  # #############################
  # Envoi de fichier
  # #############################
  
  #
  #echo "<br>\FILES :"; var_dump($_FILES)."<br>"; #<----------------------VERIF
  #
  if (count($_FILES)>0){
    
    
    $nomOrigine = $_FILES['monfichier']['name'];
    $elementsChemin = pathinfo($nomOrigine);
    
    #
    #        echo "<br>\$elementsChemin :"; var_dump($elementsChemin)."<br>";  #<----------------------VERIF
    #
    if ($elementsChemin["filename"]) {$extensionFichier = $elementsChemin['extension'];};
    $extensionsAutorisees = array("jpeg", "jpg", "gif","png");
    
    #    
    #    echo "<br>\$extensionFichier :"; var_dump($extensionFichier)."<br>"; #<----------------------VERIF
    #            
    
    if(isset($extensionFichier))
      {      
        if (!(in_array($extensionFichier, $extensionsAutorisees)))
          {
            echo "Le fichier n'a pas l'extension attendue";
          }
        else
          {    
            // Copie dans le repertoire du script avec un nom comprenant la date
            $repertoireDestination = dirname(__FILE__)."/images/";
            $nomDestination = $_POST["reference"].date("Ymd").".".$extensionFichier;
            
            if (move_uploaded_file($_FILES["monfichier"]["tmp_name"], 
              $repertoireDestination.$nomDestination))
              {
                echo "<hr>Le fichier temporaire ".$_FILES["monfichier"]["tmp_name"].
                " a été déplacé vers ".$repertoireDestination.$nomDestination."<hr>";
              }
            else
              {
                echo "<hr>ATTENTION : Le fichier n'a pas été uploadé (trop gros ?) ou ".
                "Le déplacement du fichier temporaire a échoué".
                " vérifiez l'existence du répertoire ".$repertoireDestination."<hr>";
              }
          };
      };
    
    
    
    if (isset($nomDestination))
      {
        try {
          $connection = new mysqli($host, $username, $password, $dbname);
          
          $sql = "UPDATE matos SET 
          photo = '".$nomDestination."' WHERE id = ".$id." ;";
          
          $statement = $connection->query($sql);
          
          $connection->close();
          
        } catch(Exception $error) {
          echo $sql . "<br>" . $error->getMessage();
        }
      };
  };
  
  #
  #echo "<br>\$DESTINATION :"; var_dump($nomDestination)."<br>";  #<----------------------VERIF
  #
  
  if(isset($nomDestination))  
    {
      if ($nomDestination<>'')
        {
          $photo = $nomDestination;
        };
      
    }
  else {
    $photo = $_POST["photo"];    
  };
  
  #
  #echo "<br>\$PHOTO :"; var_dump($photo)."<br>";  #<----------------------VERIF
  #  

?>

<!--# #############################-->
<!--# Code HTML-->
<!--# #############################-->
<body><p>
  <?php 
    if (count($_SESSION) > 0)
  { ?>
  <form action="index.php" method="post"><?php echo $connect." "; ?><input type='submit' name="deconnexion" value="Déconnexion"></form><?php  
    }
    else 
  { ?>
  <a href=login.php>Connection</a><?php
    }
  ?></p>
  <hr>
  <table>
    <tr>
      <td> <h1>Gestionnaire EPI</h1></td><td rowspan=2><img src="images/logo.png" width="200"></td>
    </tr>
    <tr><td><h2>Périgord Escalade</h2></td></tr>
  </table>
  

<hr>

  <!-- Test si connecté debut -->
  <?php if (count($_SESSION) > 0)
    { 

    #
    # echo "<br>\$_POST['date_debut'] :".$_POST['date_debut']."<br>"; # <------------------------- VERIF
    #

  ?>

  
  <h3>Vérifier la fiche EPI crée</h3>
  '
  <!--Formulaire de saisie -->
  
  <form method='post' action="fiche_maj_dev.php" enctype="multipart/form-data">
    <table>
      <tbody>
        <tr>
          <th>Ref</th>
          <td><input type="text" name="reference" value="<?php echo $_POST['reference']; ?>"></td><td>Photo</td>
          <td><input name="photo" value="<?php echo $photo; ?>"></td>
        </tr>
        <tr>
          <th>Libelle</th>
          <td><input type="text" name="libelle" value="<?php echo $_POST['libelle']; ?>"></td><td rowspan = 7 colspan=2><img src = images/<?php echo $photo; ?> width='400'></td>
        </tr>
        <tr>
          <th>Categorie</th>
          <td>            
            <select name='categorie_id'>
              <?php echo $listeCategories ?>
            </select>
          </td>
        </tr>
        <tr>
          <th>Fabricant</th>
          <td>           
            <select name='fabricant_id' value=<?php echo $_POST['fabricant_id']; ?>>
              <?php echo $listeFabricants ?>
            </select></td>
        </tr>
        <tr>
          <th>Lieu</th>
          <td>
            <select name='lieu_id'value=<?php echo $_POST['lieu_id']; ?>>
              <?php echo $listeLieux ?>
            </select>
          </td>
        </tr> 
        <tr>
          <th>Nb elements</th>
          <td><input type="number" name="nb_elements_initial" value=<?php echo $_POST['nb_elements_initial']; ?>></td>
        </tr>
        <tr>
          <th>Facture</th>
          <td>
            <select name='facture_id' value=<?php echo $_POST['facture_id']; ?>>
              <?php echo $listeFactures ?>
            </select>
          </td>
        </tr>
        
        <tr>
          <th>Date mise en service</th>
          <td><input type="date" name="date_debut" value="<?php echo $_POST['date_debut']; ?>"></td>
        </tr>
        <tr>
          <th colspan =4 >remarques</th>
        </tr>
        <tr>
          <td colspan = 4><textarea name="remarques" cols = 100 rows=5 ><?php echo $_POST['remarques']; ?></textarea> </td>
        </tr>
        <tr>
          <td><input type="hidden" name="MAX_FILE_SIZE" value="2000000" />  Envoyer une image : </td>
          <td colspan=3><input type="file" name="monfichier" /></td>
        </tr>
      </tbody>
    </table>
    <p></p>
    <input type='hidden' name='id' value =<?php echo $id ?> >
    <input type="submit" name="envoyer" value="Mise à jour de la fiche">
  </form>
<!-- envoi de la photo -->

<!--Pied de page-->

<hr>
<p></p>

<p>
  <a href='liste_selection.php'><strong>Retour à la liste</strong></a> - Saisir de nouveaux EPI
</p>
<p>
  <a href="index.php"><strong>Retour à l'accueil</strong></a> - Revenir à l'accueil
</p>

<!---->
  <!-- Test si connecté fin -->
  <?php 
    }
    else { ?>
  <p>Tu n'es pas connecté</p>
  <?php 
  }?>
  <!---->
<?php require "footer.php"; ?>