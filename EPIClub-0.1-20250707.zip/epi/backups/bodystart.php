
  <body><p align="right">
    <?php 
    if (count($_SESSION > 0))
    { ?>
      <form action="index.php" method="post"><?php echo $connect." "; ?><input type='submit' name="deconnexion" value="Déconnexion"></form><?php  
    }
    else 
    { ?>
          <a href=login.php>Connection</a><?php
    }
    ?></p>
    <hr>
    <table>
      <tr>
        <td> <h1>Gestionnaire EPI</h1></td><td rowspan=2><img src="images/logo.png" width="200"></td>
      </tr>
      <tr><td><h2>Périgord Escalade</h2></td></tr>
    </table>
    