<?php
if ($_SESSION != array(0))	
{
	$connect = "Connecté comme ".$_SESSION['pseudo']." : ";
}
	else
{
		$connect = "Déconnecté";
}
?>