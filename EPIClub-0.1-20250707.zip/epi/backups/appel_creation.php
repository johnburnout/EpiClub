<?php

session_start();

require "header.php";
require "common.php";
	
?>

<body>
	<form enctype="multipart/form-data" method='post'  action='fiche_creation.php'>
		<p><input type='number' name='id' value=0></p>
		<input type="hidden" name='reference' value="">
		<input type='hidden' name='libelle' value="" >
		<input type='hidden' name='categorie' value=''>
		<input type='hidden' name='categorie_id' value=0>
		<input type='hidden' name='libelle' value=''>
		<input type='hidden' name='fabricant_id' value=0>
		<input type='hidden' name='fabricant' value=0>
		<input type='hidden' name='lieu' value=''>
		<input type='hidden' name='lieu_id' value=0>
		<input type='hidden' name='vendeur' value=''>
		<input type='hidden' name='facture_id' value=0>
		<input type='hidden' name='date_facture' value=''>
		<input type='hidden' name='username' value='jean'>
		<input type='hidden' name='utilisateur_id' value=1>
		<input type='hidden' name='nb_elements' value=4>
		<input type='hidden' name='nb_elements_initial' value=4>
		<input type='hidden' name='date_max' value='2025-06-27'>
		<input type='hidden' name='date_debut' value='2025-06-27'>
		<input type='hidden' name='verification_id' value=1>
		<input type='hidden' name='date_verification' value='2014-07-01'>
		<input type='hidden' name='remarques' value='Tout va bien'>
		<input type='hidden' name='photo' value='null.jpeg'>	
		<input type="submit" name='action' value='Mise à jour'>
		<p><input type="submit" name='action' value='creation'></p>
	</form>
<?php
	require('footer.php')
?>