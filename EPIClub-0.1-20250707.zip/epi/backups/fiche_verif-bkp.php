<?php
session_start();
# #############################
# Récupère les données communes
# #############################

include $root."includes/header.php";
require "config.php";  
include $root."includes/common.php";;

# #############################
# verification connexion
# ############################

#
#  echo "<br>\$_SESSION :"; var_dump($_SESSION)."<br>"; # <------------------------- VERIF
#
  
if (count($_SESSION) > 0)	
  {
    $connect = "Connecté comme ".$_SESSION['pseudo']." : ";
  }
else
  {
    $connect = "Déconnecté";
  }

#
  echo "<br>\$_POST : "; var_dump($_POST)."<br>"; # <------------------------- VERIF
#
  
##############################
# CREATION OU MAG
#############################
    
  $action = $_POST['action'];

if ($_POST['action'] == 'maj') {
  $miseAJour = true;
  $id = $_POST['id'];
  $bouton = "Corriger la fiche";
  if ($_POST['appel_liste'] == 0) {$nbInitial = intval($_POST['nb_elements_initial']);};
}
else {
  $miseAJour = false;
  $id = 0;
  $bouton = "Mettre à jour la fiche";
  $nbInitial = intval($_POST['nb_elements_initial']);
}
  
if ($_POST['appel_liste']==0) { $donnees = $_POST;}
  
# #############################
# Création de la connection à la base
# #############################

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$connection = new mysqli($host, $username, $password, $dbname);

# #############################
# initialisation des listes 
# #############################

# Récupération des lieux

$statement = $connection->query("SELECT * FROM lieu ORDER BY id");
$nLieux = $statement->num_rows;
$lieux = $statement->fetch_all(MYSQLI_ASSOC);

# Récupération des categories
$statement = $connection->query("SELECT * FROM categorie ORDER BY id");
$nCategorie = $statement->num_rows;
$categories = $statement->fetch_all(MYSQLI_ASSOC);

#  Récupération des fabricants
$statement = $connection->query("SELECT * FROM fabricant ORDER BY id");
$nFab = $statement->num_rows;
$fabricants = $statement->fetch_all(MYSQLI_ASSOC);

# Récupération des factures
$statement = $connection->query("SELECT * FROM facture ORDER BY id");
$nFacture = $statement->num_rows;
$factures = $statement->fetch_all(MYSQLI_ASSOC);

  
  #
#  echo "<br>\$lieux :"; var_dump($lieux)."<br>"; #<----------------------VERIF
  #  
  
  
# #############################
# Initialisation variables 
# #############################
  
  #
  #  echo "<br>\$_POST :"; var_dump($_POST)."<br>"; # <------------------------- VERIF
  #

if (isset($_POST['id'])) {$id = $_POST['id'];}
else {$id = 0; };

# #############################
# Envoi des données à la BDD 
# #############################

if ($action == 'creation') {
  try {
  $sql = "INSERT INTO matos (
    reference,
    libelle,
    categorie_id,
    fabricant_id,
    photo,
    lieu_id,
    nb_elements_initial,
    nb_elements,
    facture_id,
    remarques)
  VALUES (
    '".$_POST['reference']."',
    '".escape($_POST['libelle'])."',
    '".$_POST['categorie_id']."',
    '".$_POST['fabricant_id']."',
    '".$_POST['photo']."',
    '".$_POST['lieu_id']."',
    '".$nbInitial."',
    '".$nbInitial."',
    '".$_POST['facture_id']."',
    '".escape($_POST['remarques'])."'
      )";
  
  $statement = $connection->query($sql);
  $id = $connection->insert_id;
  $action = 'maj';
  }
  catch(Exception $error)
  {
    echo $sql . "<br>" . $error->getMessage();
  }
}  
else  {
  try {
      $sql = "UPDATE matos SET
        reference = '".$_POST['reference']."',
        libelle = '".escape($_POST['libelle'])."',
        categorie_id = '".$_POST['categorie_id']."',
        fabricant_id = '".$_POST['fabricant_id']."',
        photo = '".$_POST['photo']."',
        lieu_id = '".$_POST['lieu_id']."',
        date_debut = '".strtotime($_POST['date_debut'])."',
        nb_elements_initial = '".$nbInitial."',
        nb_elements = '".$nbInitial."',
        facture_id = '".$_POST['facture_id']."',
        remarques = '".escape($_POST['remarques'])."'
      WHERE
        id = ".$id.";";
    $statement = $connection->query($sql);}
    catch(Exception $error)
    {
      echo $sql . "<br>" . $error->getMessage();
    }
};
try {
      $connection = new mysqli($host, $username, $password, $dbname);
      
      $sql = "SELECT
      id,
      ref AS reference,
      libelle,
      categorie,
      categorie_id,
      fabricant,
      fabricant_id,
      lieu,
      lieu_id,
      vendeur,
      facture_id,
      date_facture,
      username,
      utilisateur_id,
      nb_elements,
      nb_elements_initial,
      date_max,
      date_debut,
      verification_id,
      date_verification,
      remarques,
      photo
      FROM fiche
      WHERE id = ".$id." ;";
      
      $statement = $connection->query($sql);
      
      $result = $statement->fetch_all(MYSQLI_ASSOC);
      
      #
      echo "\$result : "; var_dump($result); #<-------------------- VERIF $result
      #
      
      $donnees = $result[0];  
      foreach ($donnees as $cle => $valeur) {
        $input[$cle] = [
          "debuttexte"=>$donnees[$cle],
          "debutnum"=>$donnees[$cle],
          "date"=>$donnees[$cle]
        ];
      };
      
      #   Récupération des lieux
      
      $statement = $connection->query("SELECT * FROM lieu ORDER BY id");
      $nLieux = $statement->num_rows;
      $lieux = $statement->fetch_all(MYSQLI_ASSOC);
      $connection->close();
      
    } catch(Exception $error) {
      echo $sql . "<br>" . $error->getMessage();
    };
  
  #    
  #echo "<br>\$id :"; print_r($id)."<br>"; #<----------------------VERIF
  #
  echo "\$donnees : "; var_dump($donnees);   #<-----------------------------------VERIF DONNEES
  #            
  

  # #############################
  # Envoi de fichier
  # #############################
  
  #
  #echo "<br>\FILES :"; var_dump($_FILES)."<br>"; #<----------------------VERIF
  #
          if (count($_FILES)>0){        
            $nomOrigine = $_FILES['monfichier']['name'];
            $elementsChemin = pathinfo($nomOrigine);
            
            #
            #        echo "<br>\$elementsChemin :"; var_dump($elementsChemin)."<br>";  #<----------------------VERIF
            #
            if ($elementsChemin["filename"]) {$extensionFichier = $elementsChemin['extension'];};
            $extensionsAutorisees = array("jpeg", "jpg", "gif","png");
            
            #    
            #    echo "<br>\$extensionFichier :"; var_dump($extensionFichier)."<br>"; #<----------------------VERIF
            #            
            
            if(isset($extensionFichier))
              {      
                if (!(in_array($extensionFichier, $extensionsAutorisees)))
                  {
                    echo "Le fichier n'a pas l'extension attendue";
                  }
                else
                  {    
                    // Copie dans le repertoire du script avec un nom comprenant la date
                    $repertoireDestination = dirname(__FILE__)."/images/";
                    $nomDestination = $_POST["reference"].date("Ymd").".".$extensionFichier;
                    
                    if (move_uploaded_file($_FILES["monfichier"]["tmp_name"], 
                      $repertoireDestination.$nomDestination))
                      {
                        echo "<hr>Le fichier temporaire ".$_FILES["monfichier"]["tmp_name"].
                        " a été déplacé vers ".$repertoireDestination.$nomDestination."<hr>";
                      }
                    else
                      {
                        echo "<hr>ATTENTION : Le fichier n'a pas été uploadé (trop gros ?) ou ".
                        "Le déplacement du fichier temporaire a échoué".
                        " vérifiez l'existence du répertoire ".$repertoireDestination."<hr>";
                      }
                  };
              };
            
        
            
            if (isset($nomDestination))
              {
                try {
                  $connection = new mysqli($host, $username, $password, $dbname);
                  
                  $sql = "UPDATE matos SET 
                  photo = '".$nomDestination."' WHERE id = ".$id." ;";
                  
                  $statement = $connection->query($sql);
                  
                  $connection->close();
                  
                } catch(Exception $error) {
                  echo $sql . "<br>" . $error->getMessage();
                }
              };
          };
          
          #
          #echo "<br>\$DESTINATION :"; var_dump($nomDestination)."<br>";  #<----------------------VERIF
          #
          
          if(isset($nomDestination))  
            {
              if ($nomDestination<>'')
                {
                  $photo = $nomDestination;
                };
              
            }
          else {
            $photo = $donnees["photo"];    
          };

  #
  #echo "<br>\$PHOTO :"; var_dump($photo)."<br>";  #<----------------------VERIF
  #  
  
?>

<!--# #############################-->
<!--# Code HTML-->
<!--# #############################-->
<body><p>
  
<?php 
  if (count($_SESSION) > 0)
{ ?>
<form action="index.php" method="post"><?php echo $connect." "; ?><input type='submit' name="deconnexion" value="Déconnexion"></form><?php  
  }
  else 
{ ?>
<a href=login.php>Connection</a><?php
  }
?></p>
<hr>
<table>
  <tr>
    <td> <h1>Gestionnaire EPI</h1></td><td rowspan=2><img src="images/logo.png" width="200"></td>
  </tr>
  <tr><td><h2>Périgord Escalade</h2></td></tr>
</table>


<hr>

  <!-- Test si connecté debut -->
  <?php if (count($_SESSION) > 0)
    { 

    #
     #echo "<br>\$_POST :"; print_r($_POST); echo "<br>"; # <------------------------- VERIF
      #echo "<br>\$_post[datedebut :"; print_r($factures); echo "<br>"; # <------------------------- VERIF
      #
      
  ?>

  
<h3>Vérifier la fiche EPI crée</h3>
'
<!--Formulaire de saisie -->
   
<form method='post' action="fiche_creation.php">
    <table>
    <tbody>
        <tr>
          <th>Ref</th>
          <td><?php echo $donnees['reference'] ?></td><td>Photo</td>
          <td><?php echo $donnees['photo'] ?></td>
        </tr>
        <tr>
          <th>Libelle</th>
          <td><?php echo $donnees['libelle'] ?></td><td rowspan = 7 colspan=2><img src = images/<?php echo $donnees['photo']; ?> width='400'></td>
        </tr>
        <tr>
          <th>Catégorie</th>
          <td>
            <?php echo $categories[$donnees['categorie_id']-1]['libelle'] ?>
          </td>
        </tr>
        <tr>
          <th>Fabricant</th>
          <td>           
            <?php echo $fabricants[$donnees['fabricant_id']-1]['libelle'] ?></td>
        </tr>
        <tr>
          <th>Lieu</th>
          <td>
              <?php echo $lieux[$donnees['lieu_id']-1]['libelle'] ?>
          </td>
        </tr> 
        <tr>
          <th>Nb elements</th>
          <td><?php echo $donnees['nb_elements'] ?></td>
        </tr>
      <tr>
        <th>Facture</th>
        <td><?php echo $factures[$donnees['facture_id']-1]['vendeur']." (".$factures[$donnees['facture_id']-1]['date_facture'].")" ?></td>
      </tr>
      
        <tr>
          <th>Date mise en service</th>
          <td><?php echo $donnees['date_debut'] ?></td>
        </tr>
        <tr>
          <th colspan =4 >remarques</th>
        </tr>
        <tr>
          <td colspan = 4><?php echo $donnees['remarques'] ?></td>
        </tr>
<!--  <tr>-->
<!--    <td><input type="hidden" name="MAX_FILE_SIZE" value="2000000" />  Envoyer une image : </td>-->
<!--    <td colspan=3><input type="file" name="monfichier" /></td>-->
<!--  </tr>-->
        </tbody>
    </table>
  <p></p>
  <input type="hidden" name="fabricant_id" value='<?php echo $donnees['fabricant_id']?>'>
  <input type="hidden" name="photo" value='<?php echo $donnees['photo']?>'>
  <input type="hidden" name="lieu_id" value='<?php echo $donnees['lieu_id']?>'>
  <input type="hidden" name="date_debut" value='<?php echo $donnees['date_debut']?>'>
  <input type="hidden" name="nb_elements_initial" value='<?php echo $donnees['nb_elements_initial']?>'>
  <input type="hidden" name="nb_elements" value='<?php echo $donnees['nb_elements']?>'>
  <input type="hidden" name="fabricant_id" value='<?php echo $donnees['fabricant_id']?>'>
  <input type="hidden" name="facture_id" value='<?php echo $donnees['facture_id']?>'>
  <input type="hidden" name="remarques" value='<?php echo escape($donnees['remarques'])?>'>
  <input type="hidden" name="categorie_id" value='<?php echo $donnees['categorie_id']?>'>
  <input type="hidden" name="libelle" value='<?php echo escape($donnees['libelle'])?>'>
  <input type="hidden" name="reference" value='<?php echo $donnees['reference']?>'>  
  <input type="hidden" name="id" value='<?php echo $id?>'>
  <input type='hidden' name='action' value =<?php echo $action ?> >
  <input type='hidden' name='appel_liste' value=0>
  <input type='hidden' name='id' value =<?php echo $id ?> >
  <input type="submit" name="envoyer" value="<?php echo $bouton ?>"> <a href="index.php">
  <input type="button" value="C'est bon pour moi !">
  </a>
</form>
<!-- envoi de la photo -->
<?php
  #
  #echo "<br>\$id :"; var_dump($id)."<br>";  #<----------------------VERIF
  #  
?>  
<!--Pied de page-->

<hr>
<p></p>

<p>
  <a href='liste_selection.php'><strong>Retour à la liste</strong></a> - Saisir de nouveaux EPI
</p>
<p>
  <a href="index.php"><strong>Retour à l'accueil</strong></a> - Revenir à l'accueil
</p>

<!---->
  <!-- Test si connecté fin -->
<?php 
  }
  else { ?>
<p>Tu n'es pas connecté</p>
<?php 
}?>
<!---->
<?php require "footer.php"; ?>