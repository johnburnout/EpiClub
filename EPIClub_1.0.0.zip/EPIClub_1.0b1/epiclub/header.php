<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="x-ua-compatible" content="ie=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="icon" type="image/png" href="/images/favicon.png" />
    <title>Gestionnaire EPI - Périgord Escalade</title>

    <link rel="stylesheet" href="style.css" />
  </head>
