<?php

/**
  * Configuration pour database connection
  *
  */

$host       = "localhost";
$username   = "jean";
$password   = "xF]*/Jeul2QDGUr/";
$dbname     = "epi";

#####
  
$images     = "/images";