<?php
  
  /**
  * Configuration pour database connection
  *
  */
  
  $host       = "localhost";
  //$host= "ns3126637.ip-51-68-33.eu";
  //$username   = "jean";
  //$password   = "xF]*/Jeul2QDGUr/";
  $username = "perigord-escalade_club";
  $password = "uQIGkqR7PriOskl";
  $dbname     = "epi";
  
  $images     = "/images/";
  $enregistrements = "../enregistrements";
  $root       = $_SERVER['DOCUMENT_ROOT'].'/epi/';
?>