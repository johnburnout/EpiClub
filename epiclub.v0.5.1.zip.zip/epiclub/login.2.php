<?php
  // Activation du mode strict
  declare(strict_types=1);
  
  // Configuration du rapport d'erreurs
  error_reporting(E_ALL);
  ini_set('display_errors', '0'); // Désactivé en production
  ini_set('display_startup_errors', '0');
  ini_set('log_errors', '1');
  ini_set('error_log', __DIR__.'/logs/php_errors.log');
  
  // Configuration sécurisée des sessions
  session_name('SECURE_SESSION');
  session_set_cookie_params([
    'lifetime' => 86400, // 24h
    'path' => '/',
    'domain' => $_SERVER['HTTP_HOST'],
    'secure' => true,    // HTTPS uniquement
    'httponly' => true,  // Anti-XSS
    'samesite' => 'Strict' // Anti-CSRF
  ]);
  
  session_start();
  
  // Régénération périodique de l'ID de session
  if (!isset($_SESSION['last_regeneration'])) {
    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
  } elseif (time() - $_SESSION['last_regeneration'] > 1800) { // 30 minutes
    session_regenerate_id(true);
    $_SESSION['last_regeneration'] = time();
  }
  
  // Génération du token CSRF
  if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
  }
  
  // Chemins absolus
//define('ROOT_PATH', realpath(__DIR__));
define('LOG_PATH', __DIR__.'/logs');
//
  // Inclusion de la configuration
  require __DIR__ . '/config.php';
  
  // Initialisation
  $error_message = "";
  $isLoggedIn = isset($_SESSION['user_id']) 
  && isset($_SESSION['ip_address']) 
  && $_SESSION['ip_address'] === $_SERVER['REMOTE_ADDR']
  && isset($_SESSION['user_agent']) 
  && $_SESSION['user_agent'] === $_SERVER['HTTP_USER_AGENT'];
  
  // Traitement de la déconnexion
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deconnexion'])) {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
      error_log('Tentative de déconnexion avec token CSRF invalide');
      http_response_code(403);
      die('Erreur de sécurité: Token invalide');
    }
    
    // Nettoyage complet de la session
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
      $params = session_get_cookie_params();
      setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"], 
        $params["domain"],
        $params["secure"], 
        $params["httponly"]
      );
    }
    session_destroy();
    
    header('Location: login.php');
    exit;
  }
  
  // Traitement du formulaire de connexion
  if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['connexion'])) {
    // Validation CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
      error_log('Tentative de connexion avec token CSRF invalide');
      $error_message = "Erreur de sécurité. Veuillez réessayer.";
    } else {
      // Validation des entrées
      $pseudo = trim($_POST['pseudo'] ?? '');
      $mdp = $_POST['mdp'] ?? '';
      
      if (empty($pseudo) || empty($mdp)) {
        $error_message = "Identifiant et mot de passe requis";
      } else {
        try {
          // Connexion à la base de données
          $mysqli = new mysqli($host, $username, $password, $dbname);
          $mysqli->set_charset("utf8mb4");
          
          // Requête préparée
          $stmt = $mysqli->prepare("
                    SELECT id, username, password, role, last_login 
                    FROM utilisateur 
                    WHERE username = ? 
                    AND is_active = 1
                    LIMIT 1
                ");
          $stmt->bind_param("s", $pseudo);
          $stmt->execute();
          $result = $stmt->get_result();
          
          if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            
            // Vérification du mot de passe (en production, utiliser password_verify avec des hash)
            if ($mdp === $user['password']) {
              // Initialisation de la session
              $_SESSION['user_id'] = $user['id'];
              $_SESSION['pseudo'] = $user['username'];
              $_SESSION['role'] = $user['role'];
              $_SESSION['last_login'] = time();
              $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'];
              $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
              
              // Mise à jour du last_login
              $update_stmt = $mysqli->prepare("
                            UPDATE utilisateur 
                            SET last_login = NOW() 
                            WHERE id = ?
                        ");
              $update_stmt->bind_param("i", $user['id']);
              $update_stmt->execute();
              $update_stmt->close();
              
              // Régénération de l'ID de session
              session_regenerate_id(true);
              
              header('Location: index.php');
              exit;
            }
          }
          
          // Message d'erreur générique
          $error_message = "Identifiants incorrects";
          sleep(random_int(1, 3)); // Délai anti-bruteforce
          
          $stmt->close();
          $mysqli->close();
        } catch (mysqli_sql_exception $e) {
          error_log("Erreur MySQL: ".$e->getMessage());
          $error_message = "Erreur système. Veuillez réessayer.".$e->getMessage();
        }
      }
    }
  }
?>
<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Connexion - Gestionnaire EPI</title>
    <link rel="stylesheet" href="<?= htmlspecialchars($root.'assets/css/main.css', ENT_QUOTES) ?>">
  </head>
  <body>
    <div class="container">
      <header class="header">
        <?php if ($isLoggedIn): ?>
        <span>Connecté : <?= htmlspecialchars($_SESSION['pseudo'], ENT_QUOTES) ?></span>
        <form method="post" style="display: inline;">
          <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES) ?>">
          <button type="submit" name="deconnexion">Déconnexion</button>
        </form>
        <?php else: ?>
        <a href="login.php">Connexion</a>
        <?php endif; ?>
      </header>
      
      <main class="main-content">
        <div class="login-box">
          <?php if (!$isLoggedIn): ?>
          <h1>Connexion</h1>
          
          <?php if (!empty($error_message)): ?>
          <div class="alert"><?= htmlspecialchars($error_message, ENT_QUOTES) ?></div>
          <?php endif; ?>
          
          <form method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES) ?>">
            
            <div class="form-group">
              <label for="pseudo">Identifiant</label>
              <input type="text" id="pseudo" name="pseudo" required autofocus>
            </div>
            
            <div class="form-group">
              <label for="mdp">Mot de passe</label>
              <input type="password" id="mdp" name="mdp" required>
            </div>
            
            <button type="submit" name="connexion">Se connecter</button>
          </form>
          <?php else: ?>
          <p>Vous êtes déjà connecté.</p>
          <a href="index.php" class="button">Accéder à l'interface</a>
          <?php endif; ?>
        </div>
      </main>
      
      <footer class="footer">
        <p>&copy; <?= date('Y') ?> Périgord Escalade</p>
      </footer>
    </div>
  </body>
</html>