
<link rel="icon" type="image/png" href="<?= $root ?>images/favicon.png" />
<link rel="stylesheet" type="text/css" href="<?= $root ?>styles/style.css">
