<?php
	
	require $root."includes/bdd/creation_controle.php";
	require $root."includes/bdd/creation_fiche.php";
	require $root."includes/bdd/lecture_controle.php";
	require $root."includes/bdd/lecture_fiche.php";
	require $root."includes/bdd/liste_options.php";
	require $root."includes/bdd/maj_controle.php";
	require $root."includes/bdd/maj_fiche.php";
	
?>